const { json } = require('express');
let jsonData = require('./JSON test.json');

const fs = require('fs');
console.log(jsonData);

jsonData[5]='fifth'
var jsonarr=JSON.stringify(jsonData);
console.log(jsonarr)
fs.writeFileSync('JSON test.json',jsonarr)