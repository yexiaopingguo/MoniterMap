const express = require('express');
const multer = require('multer');
const path = require('path');
const uuid = require('uuid').v4;
const app = express();
const fs = require('fs');
var upload=multer();
let jsonData = require('./Public/maplist.json');
var fileoriname;
app.use(express.static('public'))
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public')
    },
    filename: (req, file, cb) => {
        const { originalname } = file;
        // or 
        // uuid, or fieldname
        fileoriname=originalname;
        cb(null, originalname);
    }
})
 upload = multer({ storage }); // or simply { dest: 'uploads/' }


app.post('/fileform', upload.array('fileinput'), (req, res) => {

    var foldername=`public/${req.body.filename}`;
    fs.mkdir(path.join(__dirname, foldername), (err) => {
        if (err) {
            return console.error(err);
        }
        console.log('Directory created successfully!');
    });
    fs.rename(`public/${fileoriname}`,`${foldername}/${fileoriname}`,(err)=>{
        if(!err){
            console.log('Move Success')
        }
        else{
            return console.error(err)
        }
        
    })

    jsonData[req.body.filename]=fileoriname;
    var jsonarr=JSON.stringify(jsonData);
    console.log(jsonarr)
    fs.writeFileSync('public/maplist.json',jsonarr)

    return res.redirect('back')
});


app.listen(3000);